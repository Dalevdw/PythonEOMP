from tkinter import *
import mysql
from mysql import connector
from tkinter import messagebox

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='Hospital', auth_plugin='mysql_native_password')
mycursor = mydb.cursor()

def verify():
    user_verification = user_ent.get()
    pass_verification = user_ent.get()
    sql = "select * from Login where user = %s and password = %s"
    mycursor.execute(sql, [(user_verification), (pass_verification)])
    results = mycursor.fetchall()
    if results:
        for i in results:
            login()
            break
    else:
        failed()

def login():
    messagebox.showinfo("You have logged in successfully!")
    import Secfile
    Secfile.mainloop()

def failed():
    messagebox.showinfo("Error login, please try again")
    user_ent.delete(0, END)
    pass_ent.delete(0, END)


root = Tk()
root.geometry("350x300")
root.title("Login")
root.configure(background="teal")

login_lbl = Label(root, text="Sign in:")
login_lbl.grid(row=0, column=2)
login_lbl.configure(background="teal")

user_lbl = Label(root, text="Username:")
user_lbl.grid(row=2, column=0)
user_lbl.configure(background="teal")

user_ent = Entry(root, width=20)
user_ent.grid(row=2, column=2)

pass_lbl = Label(root, text="Password:")
pass_lbl.grid(row=4, column=0)
pass_lbl.configure(background="teal")

pass_ent = Entry(root, width=20)
pass_ent.grid(row=4, column=2)

login_btn = Button(root, text="Sign in", command=verify)
login_btn.grid(row=6, column=2)


root.mainloop()
