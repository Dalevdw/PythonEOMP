from tkinter import *
root = Tk()
root.geometry("350x200")
root.title("Student")
root.configure(background="teal")

root.mainloop()
